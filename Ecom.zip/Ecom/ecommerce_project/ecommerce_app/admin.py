from django.contrib import admin

# Register your models here.
from .models import Product, Order, OrderItem,Login,Register

admin.site.register(Product)
admin.site.register(Order)
admin.site.register(OrderItem)
admin.site.register(Login)
admin.site.register(Register)